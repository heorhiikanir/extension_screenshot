
console.log("abc");
var div=document.createElement("div");
document.body.appendChild(div); 
div.innerText="test123";